import pymysql

endpoint = "occres.cvqohbstc63d.us-east-1.rds.amazonaws.com"
username = "admin"
password = "ocrres1234"
database_name = "ocrres"

connection = pymysql.connect(host = endpoint, user = username, password = password, db = database_name)
def lambda_handler():
    with connection:
        # with connection.cursor() as cursor:
        #     # Create a new record
        #     sql = "INSERT INTO `RESULT_TYPE1` (`Item_name`, `Result`, `ResultLorH`, `units`) VALUES (%s, %s, %s, %s)"
        #     #sql = "select * from RESULT_TYPE1"
        #     cursor.execute(sql, ("a", 'b', 'c', 'd'))
        #     connection.commit()

        with connection.cursor() as cursor:
            sql = "select * from RESULT_TYPE1"
            cursor.execute(sql)
            rows = cursor.fetchall()
            for row in rows:
                print("{0} {1} {2} {3}".format(row[0],row[1], row[2],row[3]))
